# Advanced_PM_Group14
Code for our Advanced Process Mining project on eventually follows activity prediction.

- To run the project you need, the final code notebook. The input data is included.
- Note, it is advised to create a fresh virtual environment with python 3.11+ and install the requirements.txt
